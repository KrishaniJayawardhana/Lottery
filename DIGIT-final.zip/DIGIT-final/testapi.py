
from flask import Flask, request
from flask_restful import Resource, Api
from flask_cors import CORS, cross_origin
from flask import jsonify
import shutil
import os
import base64
from PIL import Image
#import demo as dm
import digit as dg



app = Flask(__name__)
cors = CORS(app, resources={r"*": {"origins": "*"}})
api = Api(app)



class shopClassifier_api(Resource):
    @app.route('/',methods=['POST'])
    def post(self):

        receivedData = request.get_json()
      
        text = receivedData['text']
        print()
        byte_check = text[0:2]
        if byte_check == "b'":            
            text = text[2:len(text)-1]
            img = base64.b64decode(text)
        else:
            img = base64.b64decode(text)
        

        with open("C:\\Users\\krishani\\Desktop\\CDAP\\DIGIT-final\\demo_image\\test2.jpg",'wb') as f:
            f.write(img)
        

        try:            
            #res = dm.run()
            res = dg.digit_predict()
        	
            returnJson = {
            	'result': res,
            	'status': 200 
	        }
            return jsonify(returnJson) 
        except Exception as e:
        	returnJson = {
            	'msg': e,
            	'status': 500
        	}
        	return jsonify(returnJson)
       

api.add_resource(shopClassifier_api,'/expression/')

if __name__ == '__main__':
    #app.run()
    
    app.run(host='192.168.1.102', port=5000, debug=False)
    
# Home route
@app.route('/api')
def welcome():
    return 'DIGIT API'