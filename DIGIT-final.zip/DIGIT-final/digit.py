import cv2
import pytesseract
import os

def digit_predict():
    main_dir = os.getcwd()
    image = cv2.imread(os.path.join(main_dir,"demo_image\\test2.jpg"))
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.threshold(gray, 0, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    final_decode_string=""
    blurred = cv2.GaussianBlur(gray, (3,3), 0)
    sharp = cv2.addWeighted(blurred, 1.5, blurred, -0.2, 0)
    cv2.imwrite('tesseract.jpg', sharp)
    
    text = pytesseract.image_to_string('tesseract.jpg', config='-psm 6')
    encoded_string = text.encode("ascii", "ignore")
    decode_string = encoded_string.decode()
    if not decode_string:
        decode_string = "Please Try Again"
        return decode_string
    decode_string = decode_string.split(" ")
    
    for digit in decode_string:
        final_decode_string = final_decode_string + digit+","
        
    return final_decode_string